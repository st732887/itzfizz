# ITZFIZZ — Scroll Hero Animation

A scroll-driven hero section built with **Next.js 14 · TypeScript · Tailwind CSS · GSAP ScrollTrigger**.

## 🚀 Stack
| Tech | Role |
|---|---|
| Next.js 14 (App Router) | Framework |
| TypeScript | Type safety |
| Tailwind CSS | Utility styles |
| GSAP + ScrollTrigger | All animations |

## 📁 File Structure
```
itzfizz/
├── app/
│   ├── layout.tsx        # Root layout + Google Fonts
│   ├── page.tsx          # Page — assembles Navbar + HeroSection + AfterSection
│   └── globals.css       # Tailwind directives + custom CSS (road, curb, keyframes)
├── components/
│   ├── Navbar.tsx        # Fixed nav bar (GSAP load animation)
│   ├── HeroSection.tsx   # Sticky track + ScrollTrigger orchestration
│   ├── Road.tsx          # Road div — trail, headline letters, car mount
│   ├── CarSVG.tsx        # Inline SVG McLaren 720S top-view silhouette
│   ├── StatCard.tsx      # Reusable stat card (4 colour variants)
│   └── AfterSection.tsx  # Post-hero section with IntersectionObserver reveals
├── public/
│   └── index.html        # ✅ Standalone build — deploy directly to GitHub Pages
├── tailwind.config.ts
├── postcss.config.js
├── tsconfig.json
└── next.config.js
```

## ✨ Features
- **Load animations**: Navbar slides down, scroll hint fades in — all via GSAP `expo.out`
- **Scroll-driven car**: McLaren SVG moves left → right tied exactly to scroll progress (`scrub: 1.1`)
- **Letter reveal**: Each headline letter lights up as the car "passes" it
- **Lime trail**: Grows behind the car filling the road
- **Stat cards**: Appear at scroll thresholds (20% / 42% / 62% / 78%)
- **After section**: IntersectionObserver staggered reveal

## 🖥️ Local Dev (Next.js)
```bash
npm install
npm run dev
# → http://localhost:3000
```

## 🌐 Deploy to GitHub Pages (Instant)
The `public/index.html` is a fully self-contained standalone file (no build needed):

1. Create a new GitHub repo
2. Upload `public/index.html` as `index.html` to the repo root
3. Go to **Settings → Pages → Source: main / root**
4. Live at: `https://yourusername.github.io/itzfizz-scroll-hero`

## 🏗️ Deploy Next.js (Vercel)
```bash
npm install -g vercel
vercel
# follow prompts — live in ~60 seconds
```
