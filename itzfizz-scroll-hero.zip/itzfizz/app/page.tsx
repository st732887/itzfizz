import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AfterSection from "@/components/AfterSection";

export default function Home() {
  return (
    <main>
      <Navbar />
      <HeroSection />
      <AfterSection />
    </main>
  );
}
