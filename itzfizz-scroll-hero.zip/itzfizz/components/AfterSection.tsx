"use client";

import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function AfterSection() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ref.current!.querySelectorAll(".reveal"),
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: ref.current,
            start: "top 80%",
          },
        }
      );
    }, ref);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={ref}
      className="min-h-[70vh] bg-[#0d0d0d] flex flex-col items-center justify-center gap-5 px-8 py-28"
    >
      <span className="reveal inline-block px-4 py-1.5 border border-white/15 rounded-full font-mono text-[0.62rem] tracking-[0.18em] text-white/45 uppercase">
        Case Study — 2024
      </span>

      <h2 className="reveal font-syne font-extrabold text-center text-white leading-tight"
          style={{ fontSize: "clamp(2rem, 5vw, 4rem)" }}>
        Results that move<br />at full speed.
      </h2>

      <p className="reveal font-mono text-white/40 text-[0.82rem] tracking-[0.06em] text-center leading-relaxed">
        ITZFIZZ helped brands accelerate their logistics<br />
        experience from 0 to 100.
      </p>

      <div className="reveal mt-4 grid grid-cols-3 gap-6">
        {[
          { n: "58%", l: "Pick-up growth" },
          { n: "23%", l: "Call reduction" },
          { n: "40%", l: "Fewer complaints" },
        ].map((s) => (
          <div
            key={s.n}
            className="text-center px-6 py-4 rounded-xl border border-white/10 bg-white/[0.03]"
          >
            <div className="font-syne font-extrabold text-3xl text-[#d1f542]">{s.n}</div>
            <div className="font-mono text-[0.65rem] text-white/40 tracking-[0.1em] mt-1 uppercase">{s.l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
