"use client";

/**
 * CarSVG – a stylised top-down McLaren 720S silhouette.
 * Rendered inline so no external asset is needed.
 * The car faces RIGHT (nose at the right side).
 */
export default function CarSVG({ className = "" }: { className?: string }) {
  return (
    <svg
      className={`car-img ${className}`}
      viewBox="0 0 340 160"
      xmlns="http://www.w3.org/2000/svg"
      style={{ filter: "drop-shadow(0 10px 28px rgba(0,0,0,0.7))" }}
    >
      {/* ── MAIN BODY ── */}
      <ellipse cx="170" cy="80" rx="155" ry="44" fill="#e86810" />

      {/* body highlights */}
      <ellipse cx="170" cy="80" rx="148" ry="36" fill="#f07818" opacity="0.6" />

      {/* ── NOSE CONE ── */}
      <path
        d="M322 80 Q340 66 337 80 Q340 94 322 80Z"
        fill="#cc5800"
      />

      {/* front splitter */}
      <path
        d="M310 68 L330 54 L336 60 L316 72Z"
        fill="#b54d00"
      />
      <path
        d="M310 92 L330 106 L336 100 L316 88Z"
        fill="#b54d00"
      />

      {/* ── TAIL ── */}
      <path
        d="M20 80 Q4 65 8 80 Q4 95 20 80Z"
        fill="#a04500"
      />

      {/* rear diffuser fins */}
      <path d="M22 62 L4 50 L8 44 L26 58Z" fill="#8c3c00" />
      <path d="M22 98 L4 110 L8 116 L26 102Z" fill="#8c3c00" />

      {/* ── COCKPIT CANOPY ── */}
      <path
        d="M155 46 Q178 26 215 32 Q248 37 255 58 Q258 80 248 100 Q235 116 210 118 Q178 120 155 100 Q148 90 148 80 Q148 66 155 46Z"
        fill="#111827"
      />
      {/* inner canopy / glass */}
      <path
        d="M160 50 Q180 32 212 38 Q240 43 246 60 Q248 80 240 98 Q228 112 208 114 Q180 116 162 98 Q156 88 156 80 Q156 68 160 50Z"
        fill="#0d1117"
        opacity="0.9"
      />
      {/* windscreen glint */}
      <path
        d="M165 54 Q185 38 210 44 Q225 54 220 68 Q200 52 165 54Z"
        fill="rgba(255,255,255,0.14)"
      />
      {/* side mirrors */}
      <path d="M175 46 L158 36 L162 30 L178 42Z" fill="#cc5800" />
      <path d="M175 114 L158 124 L162 130 L178 118Z" fill="#cc5800" />

      {/* ── FRONT WHEELS ── */}
      {/* front-left (top) */}
      <ellipse cx="262" cy="48" rx="16" ry="20" fill="#1a1a1a" />
      <ellipse cx="262" cy="48" rx="9"  ry="12" fill="#333" />
      <ellipse cx="262" cy="48" rx="4"  ry="5"  fill="#555" />
      {/* front-right (bottom) */}
      <ellipse cx="262" cy="112" rx="16" ry="20" fill="#1a1a1a" />
      <ellipse cx="262" cy="112" rx="9"  ry="12" fill="#333" />
      <ellipse cx="262" cy="112" rx="4"  ry="5"  fill="#555" />

      {/* ── REAR WHEELS ── */}
      {/* rear-left (top) */}
      <ellipse cx="88" cy="44" rx="19" ry="24" fill="#1a1a1a" />
      <ellipse cx="88" cy="44" rx="11" ry="14" fill="#333" />
      <ellipse cx="88" cy="44" rx="5"  ry="6"  fill="#555" />
      {/* rear-right (bottom) */}
      <ellipse cx="88" cy="116" rx="19" ry="24" fill="#1a1a1a" />
      <ellipse cx="88" cy="116" rx="11" ry="14" fill="#333" />
      <ellipse cx="88" cy="116" rx="5"  ry="6"  fill="#555" />

      {/* ── HEADLIGHTS ── */}
      <path
        d="M318 73 Q330 68 333 73 Q330 78 318 76Z"
        fill="#d1f542"
        opacity="0.95"
      />

      {/* ── TAIL LIGHTS ── */}
      <path
        d="M24 73 Q12 68 10 73 Q12 78 24 76Z"
        fill="#ff2222"
        opacity="0.9"
      />

      {/* ── LIVERY STRIPE (lime accent) ── */}
      <path
        d="M230 42 L110 44 L96 80 L110 116 L230 118"
        fill="none"
        stroke="#d1f542"
        strokeWidth="2.5"
        opacity="0.55"
        strokeLinecap="round"
      />

      {/* front brake duct vents */}
      <rect x="240" y="55"  width="16" height="4" rx="2" fill="#111" opacity="0.7" />
      <rect x="240" y="101" width="16" height="4" rx="2" fill="#111" opacity="0.7" />
    </svg>
  );
}
