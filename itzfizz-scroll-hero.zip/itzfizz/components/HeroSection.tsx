"use client";

import { useEffect, useRef, useCallback } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Road from "./Road";
import StatCard from "./StatCard";

gsap.registerPlugin(ScrollTrigger);

/* ── stat data ── */
const STATS = [
  {
    id: "s1",
    percentage: "58%",
    label: "Increase in pick‑up\npoint utilisation",
    tag: "Pick-up",
    variant: "lime" as const,
    pos: { top: "6%", right: "36%", minW: "200px" },
  },
  {
    id: "s2",
    percentage: "27%",
    label: "Increase in repeat\ncustomer orders",
    tag: "Growth",
    variant: "dark" as const,
    pos: { top: "6%", right: "8%", minW: "200px" },
  },
  {
    id: "s3",
    percentage: "23%",
    label: "Decrease in customer\nphone calls",
    tag: "Support",
    variant: "sky" as const,
    pos: { bottom: "6%", right: "36%", minW: "200px" },
  },
  {
    id: "s4",
    percentage: "40%",
    label: "Reduction in delivery\ncomplaints",
    tag: "NPS",
    variant: "orange" as const,
    pos: { bottom: "6%", right: "8%", minW: "200px" },
  },
];

/* stat card scroll thresholds */
const STAT_THRESHOLDS = [0.22, 0.44, 0.64, 0.8];

export default function HeroSection() {
  const sectionRef   = useRef<HTMLDivElement>(null);
  const trackRef     = useRef<HTMLDivElement>(null);
  const hintRef      = useRef<HTMLDivElement>(null);
  const statRefs     = useRef<(HTMLDivElement | null)[]>([]);
  const roadRef      = useRef<HTMLDivElement>(null);

  /* road scroll callback */
  const handleProgress = useCallback(() => {}, []);

  /* ── LOAD ANIMATIONS ── */
  useEffect(() => {
    const ctx = gsap.context(() => {
      /* scroll hint */
      gsap.fromTo(
        hintRef.current,
        { opacity: 0, y: 10 },
        { opacity: 1, y: 0, duration: 0.8, ease: "power3.out", delay: 1.0 }
      );

      /* stat cards initial hide */
      gsap.set(statRefs.current, { opacity: 0, y: 28 });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  /* ── SCROLL TRIGGER ── */
  useEffect(() => {
    if (typeof window === "undefined") return;

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: "top top",
        end: "bottom top",
        pin: trackRef.current,
        scrub: 1.2,
        onUpdate(self) {
          const p = self.progress;

          /* drive the road/car/trail/letters */
          const road = document.getElementById("road") as any;
          if (road?._scrollUpdate) road._scrollUpdate(p);

          /* hide scroll hint once started */
          if (p > 0.04 && hintRef.current) {
            gsap.to(hintRef.current, { opacity: 0, duration: 0.3, overwrite: "auto" });
          }

          /* reveal stat cards */
          statRefs.current.forEach((card, i) => {
            if (!card) return;
            const threshold = STAT_THRESHOLDS[i];
            if (p >= threshold) {
              const t = Math.min((p - threshold) / 0.14, 1);
              card.style.opacity = String(t);
              card.style.transform = `translateY(${(1 - t) * 28}px)`;
            } else {
              card.style.opacity = "0";
              card.style.transform = "translateY(28px)";
            }
          });
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative"
      style={{ height: "300vh" }}
    >
      {/* ── STICKY TRACK ── */}
      <div
        ref={trackRef}
        className="sticky top-0 w-full overflow-hidden flex flex-col"
        style={{
          height: "100vh",
          backgroundColor: "var(--track)",
        }}
      >
        {/* ── STAT CARDS (absolutely positioned in upper area) ── */}
        <div className="absolute inset-0 z-20 pointer-events-none" aria-live="polite">
          {STATS.map((s, i) => (
            <StatCard
              key={s.id}
              ref={(el) => { statRefs.current[i] = el; }}
              percentage={s.percentage}
              label={s.label}
              tag={s.tag}
              variant={s.variant}
              style={{
                position: "absolute",
                minWidth: s.pos.minW,
                opacity: 0,
                ...s.pos,
              }}
            />
          ))}
        </div>

        {/* ── UPPER GREY AREA ── */}
        <div className="flex-1 relative" style={{ minHeight: "62vh" }} />

        {/* ── CURB (top) ── */}
        <div className="curb-checker w-full" style={{ height: "12px" }} />

        {/* ── ROAD ── */}
        <div ref={roadRef}>
          <Road onProgress={handleProgress} />
        </div>

        {/* ── CURB (bottom) ── */}
        <div
          className="curb-checker w-full"
          style={{ height: "12px", transform: "scaleX(-1)" }}
        />

        {/* ── SCROLL HINT ── */}
        <div
          ref={hintRef}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-30 select-none"
          aria-hidden="true"
        >
          <span className="font-mono text-[0.58rem] tracking-[0.22em] uppercase text-[#333]">
            scroll
          </span>
          <div
            className="scroll-hint-bar w-px bg-[#333]"
            style={{ height: "44px" }}
          />
        </div>
      </div>
    </section>
  );
}
