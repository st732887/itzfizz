"use client";

import { useEffect, useRef } from "react";
import { gsap } from "gsap";

const links = ["Work", "Services", "About", "Contact"];

export default function Navbar() {
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    gsap.fromTo(
      navRef.current,
      { y: -30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: "power3.out", delay: 0.1 }
    );
  }, []);

  return (
    <nav
      ref={navRef}
      className="nav-blend fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-12 py-5"
    >
      <span className="text-white font-syne font-extrabold text-lg tracking-[0.18em]">
        ITZFIZZ
      </span>
      <div className="flex gap-8">
        {links.map((link) => (
          <a
            key={link}
            href="#"
            className="font-mono text-[0.7rem] text-white/70 hover:text-white tracking-[0.12em] uppercase transition-opacity duration-200"
          >
            {link}
          </a>
        ))}
      </div>
    </nav>
  );
}
