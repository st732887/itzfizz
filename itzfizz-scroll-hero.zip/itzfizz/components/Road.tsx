"use client";

import { useRef, useEffect } from "react";
import { gsap } from "gsap";
import CarSVG from "./CarSVG";

interface RoadProps {
  onProgress: (p: number) => void;
}

const HEADLINE = "WELCOME ITZFIZZ";
const CAR_W_VW = 22; // % of viewport width

export default function Road({ onProgress }: RoadProps) {
  const roadRef      = useRef<HTMLDivElement>(null);
  const carRef       = useRef<HTMLDivElement>(null);
  const trailRef     = useRef<HTMLDivElement>(null);
  const pctRef       = useRef<HTMLSpanElement>(null);
  const lettersRef   = useRef<HTMLSpanElement[]>([]);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const road    = roadRef.current!;
    const car     = carRef.current!;
    const trail   = trailRef.current!;
    const pctEl   = pctRef.current!;

    // Measure once, update on resize
    let roadW = 0;
    let carW  = 0;
    let endX  = 0;

    function measure() {
      roadW = road.offsetWidth;
      carW  = car.offsetWidth;
      endX  = roadW - carW;
    }
    measure();

    // Letter positions (relative to road left)
    function getLetterMids(): number[] {
      return lettersRef.current.map((el) => {
        if (!el) return 0;
        const r = el.getBoundingClientRect();
        const rr = road.getBoundingClientRect();
        return r.left + r.width / 2 - rr.left;
      });
    }

    // The scrub update (called by parent ScrollTrigger)
    function update(progress: number) {
      const x = endX * progress;

      // move car
      gsap.set(car, { x });

      // grow trail
      const trailEnd = x + carW * 0.55;
      gsap.set(trail, { width: Math.max(0, trailEnd) });

      // pct counter
      if (pctEl) pctEl.textContent = String(Math.round(progress * 100)).padStart(2, "0") + "%";

      // reveal letters car has passed
      const carMid = x + carW * 0.65;
      const mids = getLetterMids();
      lettersRef.current.forEach((el, i) => {
        if (!el) return;
        if (carMid >= mids[i]) {
          el.style.opacity = "1";
          el.style.transform = "translateY(0)";
        } else {
          el.style.opacity = "0.06";
          el.style.transform = "translateY(4px)";
        }
      });

      onProgress(progress);
    }

    // Expose update fn on the road element so HeroSection can call it
    (road as any)._scrollUpdate = update;

    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [onProgress]);

  return (
    <div
      ref={roadRef}
      id="road"
      className="w-full relative overflow-hidden bg-[#141414]"
      style={{ height: "38vh" }}
    >
      {/* dashed center line */}
      <div
        className="road-center-line absolute inset-0 pointer-events-none"
        style={{ top: "50%", height: "3px", transform: "translateY(-50%)" }}
      />

      {/* ── TRAIL ── */}
      <div
        ref={trailRef}
        className="trail-glow absolute top-0 left-0 bottom-0 z-10"
        style={{
          width: 0,
          background: "linear-gradient(90deg, #d1f542 0%, #a8d400 100%)",
          opacity: 0.82,
        }}
      />

      {/* ── HEADLINE text ON the road ── */}
      <div
        className="absolute inset-0 flex items-center justify-center pointer-events-none z-20"
        aria-hidden="true"
      >
        <div
          style={{
            fontSize: "clamp(3.5rem, 9.5vw, 8.5rem)",
            fontWeight: 800,
            letterSpacing: "0.22em",
            color: "#111",
            display: "flex",
            userSelect: "none",
          }}
        >
          {HEADLINE.split("").map((ch, i) => (
            <span
              key={i}
              ref={(el) => { if (el) lettersRef.current[i] = el; }}
              className="hl-letter"
              style={{
                opacity: 0.06,
                transform: "translateY(4px)",
                transition: "opacity 0.22s ease, transform 0.22s ease",
                display: "inline-block",
                ...(ch === " " ? { width: "0.45em" } : {}),
              }}
            >
              {ch === " " ? "\u00A0" : ch}
            </span>
          ))}
        </div>
      </div>

      {/* ── CAR ── */}
      <div
        ref={carRef}
        className="absolute top-0 bottom-0 flex items-center z-30"
        style={{ width: `${CAR_W_VW}vw`, left: 0, willChange: "transform" }}
      >
        <CarSVG className="w-full h-auto" />
      </div>

      {/* scroll progress pct */}
      <span
        ref={pctRef}
        className="absolute right-6 top-1/2 -translate-y-1/2 z-40 font-mono text-[0.6rem] tracking-[0.18em] text-white/30 select-none"
      >
        00%
      </span>
    </div>
  );
}
