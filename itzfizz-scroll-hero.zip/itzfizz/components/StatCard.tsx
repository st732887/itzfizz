"use client";

import { forwardRef } from "react";

export interface StatCardProps {
  percentage: string;
  label: string;
  tag: string;
  variant: "lime" | "sky" | "dark" | "orange";
  className?: string;
  style?: React.CSSProperties;
}

const variantStyles: Record<StatCardProps["variant"], string> = {
  lime:   "bg-[#d1f542] text-[#111]",
  sky:    "bg-[#6ac9ff] text-[#111]",
  dark:   "bg-[#222222] text-white",
  orange: "bg-[#fa7228] text-[#111]",
};

const StatCard = forwardRef<HTMLDivElement, StatCardProps>(
  ({ percentage, label, tag, variant, className = "", style }, ref) => {
    const base = variantStyles[variant];
    const isDark = variant === "dark";

    return (
      <div
        ref={ref}
        style={style}
        className={`stat-card rounded-2xl px-7 py-6 flex flex-col gap-1 ${base} ${className}`}
      >
        <span
          className={`font-mono text-[0.58rem] tracking-[0.14em] uppercase mb-1 ${
            isDark ? "text-white/40" : "text-black/40"
          }`}
        >
          {tag}
        </span>
        <span
          className={`font-syne font-extrabold leading-none text-5xl ${
            isDark ? "text-white" : ""
          }`}
        >
          {percentage}
        </span>
        <p
          className={`font-mono text-[0.68rem] tracking-[0.04em] leading-relaxed mt-1 ${
            isDark ? "text-white/60" : "text-black/60"
          }`}
        >
          {label}
        </p>
      </div>
    );
  }
);

StatCard.displayName = "StatCard";
export default StatCard;
